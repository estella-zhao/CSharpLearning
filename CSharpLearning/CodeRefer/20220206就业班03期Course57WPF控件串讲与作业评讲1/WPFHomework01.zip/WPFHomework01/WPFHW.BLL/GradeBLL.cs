﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class GradeBLL
    {
        private GradeDAL gradeDAL = new GradeDAL();
        /// <summary>
        /// 获取年级列表
        /// </summary>
        /// <returns></returns>
        public List<GradeInfo> GetAllGrades()
        {
            return gradeDAL.GetAllGrades();
        }
    }
}
