﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class UserBLL
    {
        private UserDAL userDAL = new UserDAL();
        /// <summary>
        /// 登录系统
        /// </summary>
        /// <param name="userInfo"></param>
        /// <returns></returns>
        public bool Login(UserInfo userInfo)
        {
            return userDAL.Login(userInfo);
        }
    }
}
