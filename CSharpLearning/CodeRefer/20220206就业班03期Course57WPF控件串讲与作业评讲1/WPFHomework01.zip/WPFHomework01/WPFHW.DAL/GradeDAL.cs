﻿using DAL.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
     public  class GradeDAL:BaseDAL<GradeInfo>
    {
        /// <summary>
        /// 获取年级列表
        /// </summary>
        /// <returns></returns>
        public List<GradeInfo> GetAllGrades()
        {
            return GetModelList("", "", 0);
        }
    }
}
