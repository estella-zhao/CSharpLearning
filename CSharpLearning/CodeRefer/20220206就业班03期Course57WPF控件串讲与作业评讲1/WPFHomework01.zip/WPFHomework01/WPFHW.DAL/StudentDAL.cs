﻿using DAL.Base;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
    public class StudentDAL : BaseDAL<StudentInfo>
    {
        public bool ExistStudent(string stuName,string phone)
        {
            string strWhere = "StuName=@stuName and Phone=@phone and IsDeleted=0";
            SqlParameter[] paras =
            {
                new SqlParameter("@stuName",stuName),
                new SqlParameter("@phone",phone)
            };
            return Exists(strWhere, paras);
        }

        /// <summary>
        /// 添加学生
        /// </summary>
        /// <param name="stuInfo"></param>
        /// <returns></returns>
        public bool AddStudent(StudentInfo stuInfo)
        {
            string cols = CreateSql.GetColNames<StudentInfo>("StuId");
            return Add(stuInfo, cols, 0) > 0;
        }
    }
}
