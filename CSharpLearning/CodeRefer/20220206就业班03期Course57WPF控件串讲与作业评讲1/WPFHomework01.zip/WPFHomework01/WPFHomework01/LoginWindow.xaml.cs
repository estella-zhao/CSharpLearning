﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WPFHomework01
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string name = txtUName.Text.Trim();
            string pwd = txtUPwd.Password.Trim();
            //登录过程
            UserBLL userBLL = new UserBLL();
            bool blLogin = userBLL.Login(new UserInfo() { 
                UserName=name,
                UserPwd=pwd
            });
            if(blLogin)
            {
                StudentMainWindow stuMain = new StudentMainWindow();
                stuMain.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                stuMain.Tag = name;
                stuMain.Show();
                this.Close();
            }
            else
            {
               MsgHelper.ShowErrMsg("登录账号或密码输入有误！", "登录系统");
                return;
            }
        }

        private void btnMin_Click(object sender, RoutedEventArgs e)
        {
            if(this.WindowState!=WindowState.Minimized)
            {
                this.WindowState = WindowState.Minimized;
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
