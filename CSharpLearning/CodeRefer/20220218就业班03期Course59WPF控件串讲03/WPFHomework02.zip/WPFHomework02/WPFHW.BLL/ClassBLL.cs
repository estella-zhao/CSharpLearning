﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class ClassBLL
    {
        private ClassDAL classDAL = new ClassDAL();
        /// <summary>
        /// 获取班级列表
        /// </summary>
        /// <param name="gradeId"></param>
        /// <returns></returns>
        public List<ClassInfo> GetClassList(int gradeId)
        {
            return classDAL.GetClassList(gradeId);
        }

        public List<ClassInfo> GetClassList()
        {
            return classDAL.GetClassList();
        }

        public List<ClassInfo> GetClassList(int gradeId, string keywords)
        {
            return classDAL.GetClassList(gradeId, keywords);
        }

        public ClassInfo GetClass(int classId)
        {
            return classDAL.GetById(classId, "");
        }

        public bool DeleteClass(int classId)
        {
            return classDAL.DeleteClass(classId, 0, 1);
        }

        public bool ConfirmClass(ClassInfo classInfo)
        {
            if (classInfo.ClassId > 0)
            {
                return classDAL.UpdaeClass(classInfo);
            }
            else
            {
                return classDAL.AddClass(classInfo);
            }
        }
    }
}
