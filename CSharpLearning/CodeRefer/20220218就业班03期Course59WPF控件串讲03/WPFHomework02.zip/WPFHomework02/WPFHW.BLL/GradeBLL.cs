﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class GradeBLL
    {
        private GradeDAL gradeDAL = new GradeDAL();
        /// <summary>
        /// 获取年级列表
        /// </summary>
        /// <returns></returns>
        public List<GradeInfo> GetAllGrades()
        {
            return gradeDAL.GetAllGrades();
        }

        public bool DeleteGrade(int gradeId)
        {
            List<int> ids = new List<int> { gradeId };
            return gradeDAL.DeleteGradeList(ids,0,1);
        }

        public bool DeleteGradeList(List<int> gradeIds)
        {
            return gradeDAL.DeleteGradeList(gradeIds, 0, 1);
        }

        public bool ConfirmGrade(GradeInfo grade)
        {
            if(grade.GradeId>0)
            {
                return gradeDAL.UpdaeGrade(grade);
            }
            else
            {
                return gradeDAL.AddGrade(grade);
            }
        }
    }
}
