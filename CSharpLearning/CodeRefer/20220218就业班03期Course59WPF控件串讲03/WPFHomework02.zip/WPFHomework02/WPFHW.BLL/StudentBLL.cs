﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class StudentBLL
    {
        private StudentDAL studentDAL = new StudentDAL();

        public bool ExistStudent(string stuName, string phone)
        {
            return studentDAL.ExistStudent(stuName, phone);
        }

        /// <summary>
        /// 添加学生
        /// </summary>
        /// <param name="stuInfo"></param>
        /// <returns></returns>
        public bool AddStudent(StudentInfo stuInfo)
        {
            return studentDAL.AddStudent(stuInfo);
        }
    }
}
