﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WPFHomework01
{
    /// <summary>
    /// ClassInfoWindow.xaml 的交互逻辑
    /// </summary>
    public partial class ClassInfoWindow : Window
    {
        public ClassInfoWindow()
        {
            InitializeComponent();
        }
        int editClassId = 0;
        ClassBLL classBLL = new ClassBLL();
        GradeBLL gradeBLL = new GradeBLL();
        public event Action ReloadList;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if(this.Tag!=null)
            {
                editClassId = this.Tag.GetInt();
            }
            LoadGradeList();
            if(editClassId>0)
            {
                ClassInfo classInfo = classBLL.GetClass(editClassId);
                if(classInfo!=null)
                {
                    txtClassName.Text = classInfo.ClassName;
                    txtRemark.Text = classInfo.Remark;
                    cboGrades.SelectedValue = classInfo.GradeId;
                }
                btnOK.Content = "修改";
            }
            else
            {
                cboGrades.SelectedIndex = 0;
                btnOK.Content = "新增";
            }
        }

        private void LoadGradeList()
        {
            List<GradeInfo> gradeList = gradeBLL.GetAllGrades();
            gradeList.Insert(0, new GradeInfo() { GradeId = 0, GradeName = "请选择" });
            cboGrades.ItemsSource = gradeList;
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            ClassInfo classInfo = new ClassInfo()
            {
                ClassId = editClassId,
                ClassName = txtClassName.Text.Trim(),
                GradeId=cboGrades.SelectedValue.GetInt(),
                Remark=txtRemark.Text.Trim(),
            };
            //判断名称
            //提交过程
            bool bl = classBLL.ConfirmClass(classInfo);
            string type = editClassId > 0 ? "修改" : "新增";
            string suc = bl ? "成功" : "失败";
            if (bl)
            {
                MsgHelper.ShowMsg($"班级：{classInfo.ClassName} {type} {suc}!", $"班级{type}");
                ReloadList?.Invoke();
            }
            else
            {
                MsgHelper.ShowErrMsg($"班级：{classInfo.ClassName} {type} {suc}!", $"班级{type}");
                return;
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
