﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WPFHomework01
{
    /// <summary>
    /// GradePage.xaml 的交互逻辑
    /// </summary>
    public partial class GradePage : Page
    {
        public GradePage()
        {
            InitializeComponent();
        }
        GradeBLL gradeBLL = new GradeBLL();
        List<GradeInfo> gradeList = null;
        int editGradeId = 0;
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadList();
        }

        private void LoadList()
        {
            gradeList = gradeBLL.GetAllGrades();
            lvGrades.ItemsSource = gradeList;
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            int gradeId = int.Parse(btn.Tag.ToString());
            editGradeId = gradeId;
            txtGradeName.Text = gradeList.Find(g => g.GradeId == gradeId).GradeName;
            btnOK.Content = "修改";
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            int gradeId = int.Parse(btn.Tag.ToString());
            if(gradeId>0)
            {
                //删除年级。。。。
                bool blDel = gradeBLL.DeleteGrade(gradeId);
                if(blDel)
                {
                    MsgHelper.ShowMsg("年级删除成功！", "年级删除");
                    LoadList();
                }
                else
                {
                    MsgHelper.ShowErrMsg("年级删除失败！", "年级删除");
                    return;
                }
            }
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            GradeInfo gradeInfo = new GradeInfo()
            {
                GradeId = editGradeId,
                GradeName = txtGradeName.Text.Trim()
            };
            //判断名称
            //提交过程
            bool bl = gradeBLL.ConfirmGrade(gradeInfo);
            string type = editGradeId > 0 ? "修改" : "新增";
            string suc = bl ? "成功" : "失败";
            if(bl)
            {
                MsgHelper.ShowMsg($"年级：{gradeInfo.GradeName} {type} {suc}!", $"年级{type}");
                LoadList();
            }
            else
            {
                MsgHelper.ShowErrMsg($"年级：{gradeInfo.GradeName} {type} {suc}!", $"年级{type}");
                return;
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            editGradeId = 0;
            txtGradeName.Text = "";
            btnOK.Content = "添加";
        }
    }
}
