﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class ClassBLL
    {
        private ClassDAL classDAL = new ClassDAL();
        /// <summary>
        /// 获取班级列表
        /// </summary>
        /// <param name="gradeId"></param>
        /// <returns></returns>
        public List<ClassInfo> GetClassList(int gradeId)
        {
            return classDAL.GetClassList(gradeId);
        }
        public List<ClassInfo> GetClassList(int gradeId, string keywords)
        {
            return classDAL.GetClassList(gradeId, keywords);
        }

        public List<ClassInfo> GetAllClassList(int isdeleted)
        {
            return classDAL.GetModelList("", "", isdeleted);
        }

        public bool AddClassInfo(ClassInfo classInfo)
        {
            return classDAL.Add(classInfo, "ClassName,GradeId,Remark",0)>0;
        }

        //修改
        public bool UpdateClassInfo(ClassInfo classInfo)
        {
            return classDAL.Update(classInfo, "");
        }

        public bool DeleteClass(int classId)
        {
            List<int> classlist = new List<int> { classId };
            return classDAL.DeleteClassListRelated(classlist, 0, 1);
        }

        public bool RemoveClass(int classId)
        {
            List<int> classlist = new List<int> { classId };
            return classDAL.DeleteClassListRelated(classlist, 1, 0);
        }

        public bool ConfirmClass(ClassInfo classInfo)
        {
            if (classInfo.ClassId > 0)
            {
                return AddClassInfo(classInfo);
            }
            else
            {
                return UpdateClassInfo(classInfo);
            }
        }

    }
}
