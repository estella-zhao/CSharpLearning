﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class GradeBLL
    {
        private GradeDAL gradeDAL = new GradeDAL();
        /// <summary>
        /// 获取年级列表
        /// </summary>
        /// <returns></returns>
        public List<GradeInfo> GetAllGrades(int isdeleted)
        {
            return gradeDAL.GetAllGrades(isdeleted);
        }

        public bool AddGrade(GradeInfo gradeInfo)
        {
            return gradeDAL.Add(gradeInfo, "GradeName", 0) > 0; 
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="gradeIDs"></param>
        /// <param name="delType">为0时逻辑删除</param>
        /// <param name="isDeleted"></param>
        /// <returns></returns>
        public bool DelGradeInfos(List<int> gradeIDs, int delType, int isDeleted)
        {
            return gradeDAL.DeleteList(gradeIDs, delType, isDeleted);
        }

        /// <summary>
        /// 没有关联删除
        /// </summary>
        /// <param name="gradeID"></param>
        /// <returns></returns>
        public bool DelGradeInfo(int gradeID)
        {
            List<int> gradeIDs = new List<int>() { gradeID };
            return DelGradeInfos(gradeIDs, 0, 1);
        }

        /// <summary>
        /// 关联删除
        /// </summary>
        /// <param name="gradeIDs"></param>
        /// <param name="delType"></param>
        /// <param name="isDeleted"></param>
        /// <returns></returns>
        public bool DelGradeInfosRelated(List<int> gradeIDs, int delType, int isDeleted)
        {
            return gradeDAL.DeleteGradeInfos(gradeIDs, delType, isDeleted);
        }

        public bool DelGradeInfoRelated(int gradeID, int delType, int isDeleted)
        {
            List<int> gradeIDs = new List<int>() { gradeID };
            return gradeDAL.DeleteGradeInfos(gradeIDs, delType, isDeleted);
        }

        public bool UpdateGradeInfo(GradeInfo gradeinfo)
        {
            if (gradeinfo != null)
                return gradeDAL.Update(gradeinfo, "");
            return false;
        }


    }
}
