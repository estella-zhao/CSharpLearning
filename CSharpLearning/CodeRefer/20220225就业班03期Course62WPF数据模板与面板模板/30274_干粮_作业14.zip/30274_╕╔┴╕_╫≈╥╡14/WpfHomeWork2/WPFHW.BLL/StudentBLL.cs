﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class StudentBLL
    {
        private StudentDAL studentDAL = new StudentDAL();

        public bool ExistStudent(string stuName, string phone)
        {
            return studentDAL.ExistStudent(stuName, phone);
        }

        /// <summary>
        /// 添加学生
        /// </summary>
        /// <param name="stuInfo"></param>
        /// <returns></returns>
        public bool AddStudent(StudentInfo stuInfo)
        {
            return studentDAL.AddStudent(stuInfo);
        }

        public List<StudentInfo> GetAllStu(int isdeleted)
        {
            List<StudentInfo> stulist = studentDAL.GetModelList("StuId,StuName,ClassId,Sex,Phone,Interestings", "", isdeleted);
            stulist.ForEach(s =>
            {
                s.IsMale = s.Sex == "男" ? true : false;
            });
            return stulist;
        }

        public List<StudentInfo> GetStuList(int classid, string keywords)
        {
            List<StudentInfo> stulist = studentDAL.GetStuList(classid, keywords);
            stulist.ForEach(s =>
            {
                s.IsMale = s.Sex == "男" ? true : false;
            });
            return stulist;
        }

        public bool UpdateStuInfo(StudentInfo studentInfo)
        {
            return studentDAL.Update(studentInfo, "StuId,StuName,ClassId,Sex,Phone,Interestings");
        }

        public bool DeleteStu(int stuID)
        {
            return studentDAL.DeleteStudent(stuID, 0, 1);
        }

        public bool RecoverStu(int stuID)
        {
            return studentDAL.DeleteStudent(stuID, 0, 0);
        }

        public bool RemoveStu(int stuID)
        {
            return studentDAL.DeleteStudent(stuID, 1, 1);
        }


    }
}
