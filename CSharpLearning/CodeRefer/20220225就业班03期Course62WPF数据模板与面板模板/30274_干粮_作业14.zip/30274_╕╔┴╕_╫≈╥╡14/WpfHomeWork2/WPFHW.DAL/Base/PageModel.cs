﻿namespace DAL.Base
{
    public class PageModel<S>
    {
    }
}