﻿using DAL.Base;
using Helper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
    public class ClassDAL : BaseDAL<ClassInfo>
    {
        /// <summary>
        /// 获取班级列表
        /// </summary>
        /// <param name="gradeId"></param>
        /// <returns></returns>
        public List<ClassInfo> GetClassList(int gradeId)
        {
            return GetModelList($"GradeId={gradeId} and IsDeleted=0", "ClassId,ClassName", "");
        }

        public List<ClassInfo> GetClassList(int gradeId, string keywords)
        {
            string strWhere = " IsDeleted=0";
            if (gradeId > 0)
            {
                strWhere += $" and  GradeId={gradeId}";
            }
            if (!string.IsNullOrEmpty(keywords))
            {
                strWhere += " and ClassName like @keywords";
            }
            SqlParameter para = new SqlParameter("@keywords", $"%{keywords}%");
            return GetModelList(strWhere, "ClassId,ClassName,GradeId,Remark", "", para);
        }

        /// <summary>
        /// 关联删除
        /// </summary>
        /// <param name="classlist"></param>
        /// <param name="delType"></param>
        /// <param name="isdeleted"></param>
        /// <returns></returns>
        public bool DeleteClassListRelated(List<int> classlist, int delType, int isdeleted)
        {
            List<string> sqlList = new List<string>();

            foreach (var classId in classlist)
            {
                string strWhere = $"ClassId={classId}";
                if (delType == 0)
                {
                    string delClass = CreateSql.CreateLogicDeleteSql<ClassInfo>(strWhere, isdeleted);
                    string delStudent = CreateSql.CreateLogicDeleteSql<ClassInfo>(strWhere, isdeleted);
                    sqlList.Add(delStudent);
                    sqlList.Add(delClass);
                }
                else if (delType == 1)
                {
                    string delClass = CreateSql.CreateDeleteSql<ClassInfo>(strWhere);
                    string delStudent = CreateSql.CreateDeleteSql<ClassInfo>(strWhere);
                    sqlList.Add(delStudent);
                    sqlList.Add(delClass);
                }
            }
            return SqlHelper.ExecuteTrans(sqlList);

        }

    }
}
