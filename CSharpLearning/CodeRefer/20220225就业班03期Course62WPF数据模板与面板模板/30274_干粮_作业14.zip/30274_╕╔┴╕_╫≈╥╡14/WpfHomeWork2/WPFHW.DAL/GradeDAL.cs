﻿using DAL.Base;
using Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
     public  class GradeDAL:BaseDAL<GradeInfo>
    {
        /// <summary>
        /// 获取年级列表
        /// </summary>
        /// <returns></returns>
        public List<GradeInfo> GetAllGrades(int isdeleted)
        {
            return GetModelList("", "", isdeleted);
        }


        ClassDAL classDAL = new ClassDAL();
        public bool DeleteGradeInfos(List<int> gradesIDs, int delType, int isdeleted)
        {
            List<string> listSql = new List<string>();
            string delGrade = "";
            string delClass = "";
            string delStudent = "";

            foreach (var gid in gradesIDs)
            {
                string strWhere = $"GradeId={gid}";
                if (delType==0)//逻辑删除
                {
                    delGrade = CreateSql.CreateLogicDeleteSql<GradeInfo>(strWhere, isdeleted); 
                    delClass = CreateSql.CreateLogicDeleteSql<ClassInfo>(strWhere, isdeleted);
                    delStudent = CreateSql.CreateLogicDeleteSql<ClassInfo>(" ClassId in (select ClassId from ClassInfos where  " + strWhere + ")", isdeleted);
                   
                    listSql.Add(delStudent);
                    listSql.Add(delClass);
                    listSql.Add(delGrade);
                }
                else//真删除
                {
                    delGrade = CreateSql.CreateDeleteSql<GradeInfo>(strWhere);
                    delClass = CreateSql.CreateDeleteSql<ClassInfo>(strWhere);
                    delStudent = CreateSql.CreateDeleteSql<ClassInfo>(" ClassId in (select ClassId from ClassInfos where  " + strWhere + ")");

                    listSql.Add(delGrade);
                    listSql.Add(delClass);
                    listSql.Add(delStudent);
                }
            }

            return SqlHelper.ExecuteTrans(listSql);

        }

    }
}
