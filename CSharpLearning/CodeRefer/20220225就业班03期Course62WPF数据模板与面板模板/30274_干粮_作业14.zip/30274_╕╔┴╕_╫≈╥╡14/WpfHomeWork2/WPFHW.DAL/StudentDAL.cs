﻿using DAL.Base;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
    public class StudentDAL : BaseDAL<StudentInfo>
    {
        public bool ExistStudent(string stuName,string phone)
        {
            string strWhere = "StuName=@stuName and Phone=@phone and IsDeleted=0";
            SqlParameter[] paras =
            {
                new SqlParameter("@stuName",stuName),
                new SqlParameter("@phone",phone)
            };
            return Exists(strWhere, paras);
        }

        /// <summary>
        /// 添加学生
        /// </summary>
        /// <param name="stuInfo"></param>
        /// <returns></returns>
        public bool AddStudent(StudentInfo stuInfo)
        {
            string cols = CreateSql.GetColNames<StudentInfo>("StuId,IsMale");
            return Add(stuInfo, cols, 0) > 0;
        }

        public bool UpdateStudent(StudentInfo stuInfo)
        {
            return Update(stuInfo, "");
        }

        public bool DeleteStudent(int stuid, int delType, int isdeleted)
        {
            return Delete(stuid,delType,isdeleted);
        }

        public List<StudentInfo> GetStuList(int classid, string keywords)
        {
            string strwhere = " IsDeleted=0";
            if (classid > 0 )
            {
                strwhere += $" and ClassId={classid}";
            }
            if (!string.IsNullOrEmpty(keywords))
            {
                strwhere += " and StuName like @keywords";
            }
            SqlParameter paraKeywords = new SqlParameter("@keywords", $"%{keywords}%");
            return GetModelList(strwhere, "StuID,StuName,ClassID,Sex,Phone,Interestings", "", paraKeywords);

        }
    }
}
