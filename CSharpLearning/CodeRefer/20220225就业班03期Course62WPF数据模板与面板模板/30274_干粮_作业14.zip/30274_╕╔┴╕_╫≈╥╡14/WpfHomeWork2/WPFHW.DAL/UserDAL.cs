﻿using DAL.Base;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
    public class UserDAL:BaseDAL<UserInfo>
    {
        /// <summary>
        /// 登录系统
        /// </summary>
        /// <param name="userInfo"></param>
        /// <returns></returns>
        public bool Login(UserInfo userInfo)
        {
            SqlParameter[] paras =
            {
                new SqlParameter("@userName",userInfo.UserName),
                new SqlParameter("@userPwd",userInfo.UserPwd)
            };
            if(Exists("UserName=@userName and UserPwd=@userPwd",paras))
            {
                return true;
            }
            return false;
        }
    }
}
