﻿using Common.CustAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFHW.Models
{
    [Table("StudentInfos")]
    [PrimaryKey("StuId", autoIncrement = true)]
    public class StudentInfo
    {
        public int StuId { get; set; }
        public string StuName { get; set; }
        public int ClassId { get; set; }
        public string Sex { get; set; }
        public bool IsMale { get; set; }
        public string Phone { get; set; }
        public string Interestings { get; set; }
    }
}
