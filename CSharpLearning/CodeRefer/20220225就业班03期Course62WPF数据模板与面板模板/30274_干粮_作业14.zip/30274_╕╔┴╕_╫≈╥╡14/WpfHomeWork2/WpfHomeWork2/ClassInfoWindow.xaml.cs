﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WpfHomeWork2
{
    /// <summary>
    /// ClassInfoWindow.xaml 的交互逻辑
    /// </summary>
    public partial class ClassInfoWindow : Window
    {
        public ClassInfoWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        ClassBLL classBLL = new ClassBLL();
        GradeBLL gradeBLL = new GradeBLL();

        private ClassInfo clsInfo = null;

        public event Action ReLoaddglist;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //绑定年级列表
            cboGradeName.ItemsSource = gradeBLL.GetAllGrades(0);

            if (this.Tag != null)
            {
                clsInfo = this.Tag as ClassInfo;
                txtClassName.Text = clsInfo.ClassName;
                txtClassRemark.Text = clsInfo.Remark;
                cboGradeName.SelectedValue = clsInfo.GradeId;
            }
            else
            {
                clsInfo = new ClassInfo();
                btnConfirm.Content = "新增";
            }
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (btnConfirm.Content.ToString() == "确定")//修改
            {
                if (string.IsNullOrEmpty(txtClassName.Text.Trim()))
                {
                    MsgHelper.ShowErrMsg("班级名称不可为空", "修改错误");
                    return;
                }
                else
                {
                    clsInfo.ClassName = txtClassName.Text.Trim();
                    clsInfo.GradeId = cboGradeName.SelectedValue.ToString().GetInt();
                    clsInfo.Remark = txtClassRemark.Text.Trim();
                    if (classBLL.UpdateClassInfo(clsInfo))
                    {
                        this.ReLoaddglist?.Invoke();
                    }
                }
            }
            else//新增
            {
                if (string.IsNullOrEmpty(txtClassName.Text.Trim()) || string.IsNullOrEmpty(cboGradeName.Text.Trim()))
                {
                    MsgHelper.ShowErrMsg("没有填写完整", "修改错误");
                    return;
                }
                clsInfo = new ClassInfo()
                {
                    ClassName = txtClassName.Text.Trim(),
                    GradeId = cboGradeName.SelectedValue.ToString().GetInt(),
                    Remark = txtClassRemark.Text.Trim()
                };
                if (classBLL.AddClassInfo(clsInfo))
                {
                    this.ReLoaddglist?.Invoke();
                }
            }
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
