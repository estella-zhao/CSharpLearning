﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WpfHomeWork2
{
    public class MsgHelper
    {
        public static void ShowErrMsg(string msg, string title)
        {
            MessageBox.Show(msg, title, MessageBoxButton.OK, MessageBoxImage.Error);
        }

        public static void ShowMsg(string msg, string title)
        {
            MessageBox.Show(msg, title, MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public static MessageBoxResult ShowQuestion(string msg, string title)
        {
            return MessageBox.Show(msg, title, MessageBoxButton.YesNo, MessageBoxImage.Question);
        }
    }
}
