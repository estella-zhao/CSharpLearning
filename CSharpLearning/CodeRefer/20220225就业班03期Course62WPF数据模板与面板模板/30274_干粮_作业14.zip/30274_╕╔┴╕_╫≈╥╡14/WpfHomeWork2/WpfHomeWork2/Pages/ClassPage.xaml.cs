﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WpfHomeWork2.Pages
{
    /// <summary>
    /// ClassPage.xaml 的交互逻辑
    /// </summary>
    public partial class ClassPage : Page
    {
        public ClassPage()
        {
            InitializeComponent();
        }

        GradeBLL gradeBLL = new GradeBLL();
        ClassBLL classBLL = new ClassBLL();
        List<GradeInfo> gradeInfos = new List<GradeInfo>();
        List<ClassInfo> classList = new List<ClassInfo>();
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            gradeInfos = gradeBLL.GetAllGrades(0);
            gradeInfos.Insert(0, new GradeInfo() { GradeId = 0, GradeName = "请选择" });
            cboGrades.ItemsSource = gradeInfos;
            cboGrades.SelectedIndex = 0;
            colGrades.ItemsSource = gradeInfos;
            LoadList();//班级列表
        }

        private void LoadList()
        {
            string keywords = txtClassName.Text.Trim();
            int gradeId = cboGrades.SelectedValue.GetInt();
            classList = classBLL.GetClassList(gradeId, keywords);
            dgClass.ItemsSource = classList;
        }
        private void LoadDeletedList()
        {
            classList = classBLL.GetAllClassList(1);
            dgClass.ItemsSource = classList;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button.Tag != null)
            {
                int classID = int.Parse(button.Tag.ToString());
                if (classBLL.DeleteClass(classID))
                {
                    MsgHelper.ShowMsg("班级删除成功", "班级删除");
                    LoadList();
                }
                else
                {
                    MsgHelper.ShowErrMsg("班级删除失败！", "班级删除");
                    return;
                }
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button.Tag != null)
            {
                int classID = int.Parse(button.Tag.ToString());
                ClassInfoWindow classInfoWindow = new ClassInfoWindow();
                classInfoWindow.Tag = classList.Find(c => c.ClassId == classID);
                classInfoWindow.ReLoaddglist += LoadList;
                classInfoWindow.ShowDialog();
            }
        }

        private void chkDeleted_Unchecked(object sender, RoutedEventArgs e)
        {
            LoadList();
        }

        private void chkDeleted_Checked(object sender, RoutedEventArgs e)
        {
            LoadDeletedList();
        }


        private void btnAddNewClass_Click(object sender, RoutedEventArgs e)
        {
            ClassInfoWindow classInfoWindow = new ClassInfoWindow();
            classInfoWindow.ReLoaddglist += LoadList;
            classInfoWindow.ShowDialog();
        }

        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            LoadList();
        }
    }
}
