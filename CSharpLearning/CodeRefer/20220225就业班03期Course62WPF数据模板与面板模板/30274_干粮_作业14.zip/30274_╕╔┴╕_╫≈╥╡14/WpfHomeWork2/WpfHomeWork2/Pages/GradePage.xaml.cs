﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WpfHomeWork2.Pages
{
    /// <summary>
    /// GradePage.xaml 的交互逻辑
    /// </summary>
    public partial class GradePage : Page
    {
        public GradePage()
        {
            InitializeComponent();
        }

        GradeBLL gradeBLL = new GradeBLL();
        GradeInfo modifygInfo = null;
        List<GradeInfo> gradeInfos = new List<GradeInfo>();
        private void GradePage_Loaded(object sender, RoutedEventArgs e)
        {
            ReloadedlvGrade(0);
        }

        private void ReloadedlvGrade(int isdeleted)
        {
            gradeInfos = gradeBLL.GetAllGrades(isdeleted);
            lvGrade.DataContext = gradeInfos;
            txtGradeFilter.Text = "";
        }

        private void btnModify_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button.Tag != null)
            {
                int gradeID = int.Parse(button.Tag.ToString());

                modifygInfo = gradeInfos.Find(g => g.GradeId == gradeID);
                txtGradeFilter.Text = modifygInfo != null ? modifygInfo.GradeName : "没有此年级";
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button.Tag != null)
            {
                int gradeID = int.Parse(button.Tag.ToString());
                if (gradeBLL.DelGradeInfoRelated(gradeID, 0, 1))
                {
                    MsgHelper.ShowMsg("逻辑删除成功", "年级删除");
                }
                ReloadedlvGrade(0);
            }
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtGradeFilter.Text))
            {
                if (modifygInfo != null)
                {
                    modifygInfo.GradeName = txtGradeFilter.Text.ToString();
                    //if (!gradeBLL.UpdateGradeInfo(modifygInfo))
                    //    MsgHelper.ShowMsg("修改失败", "修改");
                    if (gradeBLL.UpdateGradeInfo(modifygInfo))
                        ReloadedlvGrade(0);
                    else 
                        MsgHelper.ShowMsg("修改失败", "修改");
                }
                else
                {
                    modifygInfo = new GradeInfo() { GradeName = txtGradeFilter.Text.ToString() };
                    if (gradeBLL.AddGrade(modifygInfo))
                        ReloadedlvGrade(0);
                    else 
                        MsgHelper.ShowMsg("添加失败", "添加");
                }

            }
        }

        private void btnAddNewGrade_Click(object sender, RoutedEventArgs e)
        {
            this.txtGradeFilter.Text = "";
            modifygInfo = null;
        }


        private void chkDeleted_Checked(object sender, RoutedEventArgs e)
        {
            ReloadedlvGrade(1);
        }

        private void chkDeleted_Unchecked(object sender, RoutedEventArgs e)
        {
            ReloadedlvGrade(0);
        }
    }
}
