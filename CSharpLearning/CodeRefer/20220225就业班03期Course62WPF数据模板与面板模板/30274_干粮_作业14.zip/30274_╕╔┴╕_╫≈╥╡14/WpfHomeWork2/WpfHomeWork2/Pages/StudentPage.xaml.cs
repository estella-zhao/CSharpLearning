﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WpfHomeWork2.Pages
{
    /// <summary>
    /// StudentPage.xaml 的交互逻辑
    /// </summary>
    public partial class StudentPage : Page
    {
        public StudentPage()
        {
            InitializeComponent();
        }

        ClassBLL classBLL = new ClassBLL();
        StudentBLL studentBLL = new StudentBLL();

        List<ClassInfo> classInfos = new List<ClassInfo>();
        List<StudentInfo> studentInfos = new List<StudentInfo>();

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            classInfos = classBLL.GetAllClassList(0);
            classInfos.Insert(0, new ClassInfo() { ClassId = 0, ClassName = "请选择" });
            cboClassName.ItemsSource = classInfos;
            cboClassName.SelectedIndex = 0;
            colClasses.ItemsSource = classInfos;
            LoadStuList();
        }

        private void LoadStuList()
        {
            chkAndcolStutas(chkDeleted);
            string keywords = txtName.Text.Trim();
            int classid = cboClassName.SelectedValue.GetInt();
            studentInfos = studentBLL.GetStuList(classid, keywords);
            dgStudent.ItemsSource = studentInfos;
        }
        private void LoadDeletedList()
        {
            chkAndcolStutas(chkDeleted);
            studentInfos = studentBLL.GetAllStu(1);
            dgStudent.ItemsSource = studentInfos;
        }

        public void chkAndcolStutas(CheckBox checkBox)
        {
            if (checkBox.IsChecked == true)
            {
                colDelete.Visibility = Visibility.Collapsed;
                colEdit.Visibility = Visibility.Collapsed;
                colRemove.Visibility = Visibility.Visible;
                colRecover.Visibility = Visibility.Visible;
            }
            else
            {
                colDelete.Visibility = Visibility.Visible;
                colEdit.Visibility = Visibility.Visible;
                colRemove.Visibility = Visibility.Collapsed;
                colRecover.Visibility = Visibility.Collapsed;
            }
        }

        private void chkDeleted_Checked(object sender, RoutedEventArgs e)
        {
            LoadDeletedList();
        }

        private void chkDeleted_Unchecked(object sender, RoutedEventArgs e)
        {
            LoadStuList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button.Tag != null)
            {
                int stuId = int.Parse(button.Tag.ToString());
                StudentInfoWindow studentInfoWindow = new StudentInfoWindow();
                studentInfoWindow.Tag = studentInfos.Find(s => s.StuId == stuId);
                studentInfoWindow.LoadStuList += LoadStuList;
                studentInfoWindow.ShowDialog();
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button.Tag != null)
            {
                int stuId = int.Parse(button.Tag.ToString());
                if (studentBLL.DeleteStu(stuId))
                {
                    MsgHelper.ShowMsg("学生删除成功", "学生删除");
                    LoadStuList();
                }
                else
                {
                    MsgHelper.ShowErrMsg("学生删除失败！", "学生删除");
                    return;
                }
            }
        }

        private void btnAddNewStu_Click(object sender, RoutedEventArgs e)
        {
            StudentInfoWindow studentInfoWindow = new StudentInfoWindow();
            studentInfoWindow.LoadStuList += LoadStuList;
            studentInfoWindow.ShowDialog();
        }

        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            LoadStuList();
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button.Tag != null)
            {
                int stuId = int.Parse(button.Tag.ToString());
                if (studentBLL.RemoveStu(stuId))
                {
                    MsgHelper.ShowMsg("学生移除成功", "学生移除");
                    LoadDeletedList();
                }
                else
                {
                    MsgHelper.ShowErrMsg("学生移除失败！", "学生移除");
                    return;
                }
            }
        }

        private void btnRecover_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button.Tag != null)
            {
                int stuId = int.Parse(button.Tag.ToString());
                if (studentBLL.RecoverStu(stuId))
                {
                    MsgHelper.ShowMsg("学生恢复成功", "学生恢复");
                    LoadDeletedList();
                }
                else
                {
                    MsgHelper.ShowErrMsg("学生恢复失败！", "学生恢复");
                    return;
                }
            }
        }
    }
}
