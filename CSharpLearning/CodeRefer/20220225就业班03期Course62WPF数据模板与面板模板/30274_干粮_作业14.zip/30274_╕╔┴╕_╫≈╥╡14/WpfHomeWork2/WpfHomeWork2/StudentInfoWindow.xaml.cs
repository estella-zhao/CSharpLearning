﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WpfHomeWork2
{
    /// <summary>
    /// StudentInfoWindow.xaml 的交互逻辑
    /// </summary>
    public partial class StudentInfoWindow : Window
    {
        GradeBLL gradeBLL = new GradeBLL();
        ClassBLL classBLL = new ClassBLL();
        StudentBLL stuBLL = new StudentBLL();

        List<GradeInfo> gradeList = null;
        List<ClassInfo> classList = null;

        private StudentInfo studentInfo = null;

        public event Action LoadStuList;

        public StudentInfoWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //加载年级列表
            LoadGradeList();

            //根据Tag修改或者新增数据 
            if (this.Tag != null)
            {
                studentInfo = this.Tag as StudentInfo;
                txtName.Text = studentInfo.StuName;
                //班级先全部加载
                classList = classBLL.GetAllClassList(0);
                cboGrades.SelectedValue = classList.Find(c => c.ClassId == studentInfo.ClassId)?.GradeId;
                cboClasses.SelectedValue = studentInfo.ClassId;
                rbtnMale.IsChecked = studentInfo.IsMale;
                rbtnFeMale.IsChecked = !studentInfo.IsMale;

                //List<string> chkInterestings = studentInfo.Interestings.Split(',').ToList();
                if (studentInfo.Interestings != null)
                {
                    foreach (UIElement ele in spInterests.Children)
                    {
                        if (ele is CheckBox)
                        {
                            CheckBox ck = ele as CheckBox;
                            if (studentInfo.Interestings.Contains(ck.Content.ToString()))
                            {
                                ck.IsChecked = true;
                            }
                        }
                    }
                }
                txtPhone.Text = studentInfo.Phone;
            }
            else
            {
                studentInfo = new StudentInfo();
                btnOK.Content = "新增";
            }
        }
        private void LoadGradeList()
        {
            //绑定年级列表
            gradeList = gradeBLL.GetAllGrades(0);
            gradeList.Insert(0, new GradeInfo() { GradeId = 0, GradeName = "请选择" });
            cboGrades.ItemsSource = gradeList;
            cboGrades.DisplayMemberPath = "GradeName";
            cboGrades.SelectedValuePath = "GradeId";
            cboGrades.SelectedIndex = 0;
        }

        private void cboGrades_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //根据选择绑定班级列表
            int gradeId = cboGrades.SelectedValue.GetInt();
            classList = classBLL.GetClassList(gradeId);
            classList.Insert(0, new ClassInfo() { ClassId = 0, ClassName = "请选择" });
            cboClasses.ItemsSource = classList;
            cboClasses.DisplayMemberPath = "ClassName";
            cboClasses.SelectedValuePath = "ClassId";
            cboClasses.SelectedIndex = 0;
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text.Trim();
            int classId = cboClasses.SelectedValue.GetInt();
            string sex = rbtnMale.IsChecked == true ? "男" : "女";
            string interests = "";
            foreach (UIElement ele in spInterests.Children)
            {
                if (ele is CheckBox)
                {
                    CheckBox chk = ele as CheckBox;
                    if (chk.IsChecked == true)
                    {
                        if (interests != "") interests += ",";
                        interests += chk.Content.ToString();
                    }
                }
            }
            string phone = txtPhone.Text.Trim();

            if (string.IsNullOrEmpty(name))
            {
                MsgHelper.ShowErrMsg("请输入学生姓名！", "新增学生");
                return;
            }
            if (classId == 0)
            {
                MsgHelper.ShowErrMsg("请选择所属班级！", "新增学生");
                return;
            }
            if (string.IsNullOrEmpty(phone))
            {
                MsgHelper.ShowErrMsg("请输入手机号码！", "新增学生");
                return;
            }

            if (btnOK.Content.ToString() == "修改")//修改
            {
                studentInfo.StuName = name;
                studentInfo.ClassId = classId;
                studentInfo.Sex = sex;
                studentInfo.Interestings = interests;
                studentInfo.Phone = phone;
                if (stuBLL.UpdateStuInfo(studentInfo))
                {
                    this.LoadStuList?.Invoke();
                    MsgHelper.ShowMsg("学生修改成功！", "修改学生");
                    this.Close();
                }
                else
                {
                    MsgHelper.ShowErrMsg("学生修改失败！", "修改学生");
                    return;
                }
            }
            else//新增
            {
                studentInfo = new StudentInfo()
                {
                    StuName = name,
                    Sex = sex,
                    ClassId = classId,
                    Interestings = interests,
                    Phone = phone
                };
                if (stuBLL.AddStudent(studentInfo))
                {
                    this.LoadStuList?.Invoke();
                    MsgHelper.ShowMsg("学生新增成功！", "新增学生");
                    this.Close();
                }
                else
                {
                    MsgHelper.ShowErrMsg("学生新增失败！", "新增学生");
                    return;
                }
            }

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
