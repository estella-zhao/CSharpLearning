﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WpfHomeWork2
{
    /// <summary>
    /// StudentMainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class StudentMainWindow : Window
    {
        public StudentMainWindow()
        {
            InitializeComponent();
        }

        MenuBLL menuBLL = new MenuBLL();
        List<MenuInfo> menulist = null;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Task.Run(() =>
            {
                while (true)
                {
                    this.Dispatcher.Invoke(() =>
                    {
                         lblCurrentTime.Content = DateTime.Now.ToString("F");
                    });
                    Thread.Sleep(1000);
                }
            });

            //菜单数据获取
            menulist = menuBLL.GetMenuList() ;
            //调用递归方法
            AddMenuItems(menulist, null, 0);
            AddTreeViewItems(menulist, null, 0);

        }

        //定义一个递归加载方法 并且增加事件
        private void AddMenuItems(List<MenuInfo> allMenus, MenuItem pMenu, int parentId)
        {
            var subList = allMenus.Where(m => m.ParentId == parentId);
            foreach (var mi in subList)
            {
                MenuItem mItem = new MenuItem();
                mItem.Header = mi.MenuName;
                if (!string.IsNullOrEmpty(mi.MKey))
                    mItem.InputGestureText = mi.MKey;
                if (pMenu != null)
                    pMenu.Items.Add(mItem);//子菜单
                else
                    stuMenus.Items.Add(mItem);//一级菜单

                if (allMenus.Where(m => m.ParentId == mi.MenuId).ToList().Count==0)
                {
                    mItem.Click += MItem_Click;
                }

                AddMenuItems(allMenus, mItem, mi.MenuId);
            }
        }

        private void AddTreeViewItems(List<MenuInfo> allMenus, TreeViewItem pItem, int parentId)
        {
            var subList = allMenus.Where(m => m.ParentId == parentId);
            foreach (var mi in subList)
            {
                TreeViewItem mItem = new TreeViewItem();
                mItem.Header = mi.MenuName;
                if (pItem != null)
                    pItem.Items.Add(mItem);//子节点
                else
                    tvList.Items.Add(mItem);//根节点
                mItem.IsExpanded = true;

                if (allMenus.Where(m => m.ParentId == mi.MenuId).ToList().Count == 0)
                {
                    mItem.GotFocus += TvItem_Click;
                }

                AddTreeViewItems(allMenus, mItem, mi.MenuId);
            }
        }

        private void TvItem_Click(object sender, RoutedEventArgs e)
        {
            TreeViewItem treeViewItem  = sender as TreeViewItem;

            //MenuInfo menuInfo = menulist.Find(m => m.MenuName == treeViewItem.Header.ToString());
            //if (menuInfo.FrmName == null) return;

            foreach (UIElement ele in tabPages.Items)//点击TreeView切换TabPages
            {
                if (ele is TabItem)
                {
                    TabItem tabItem = ele as TabItem;
                    if (tabItem.Header.ToString()== treeViewItem.Header.ToString().Trim())
                    {
                        tabPages.SelectedItem = tabItem;
                    }
                }
            }
        }

        private void MItem_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menuItem = sender as MenuItem;

            //MenuInfo menuInfo = menulist.Find(m => m.MenuName == menuItem.Header.ToString());
            //if (menuInfo.FrmName == null) return
            //
            foreach (UIElement ele in tabPages.Items)
            {
                if (ele is TabItem)
                {
                    TabItem tabItem = ele as TabItem;
                    if (tabItem.Header.ToString() == menuItem.Header.ToString().Trim())
                    {
                        tabPages.SelectedItem = tabItem;
                    }
                }
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
