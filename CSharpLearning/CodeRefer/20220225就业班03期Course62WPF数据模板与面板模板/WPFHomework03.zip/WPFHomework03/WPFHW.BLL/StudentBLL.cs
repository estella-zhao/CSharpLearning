﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.DAL;
using WPFHW.Models;

namespace WPFHW.BLL
{
    public class StudentBLL
    {
        private StudentDAL studentDAL = new StudentDAL();

        public bool ExistStudent(string stuName, string phone)
        {
            return studentDAL.ExistStudent(stuName, phone);
        }

        /// <summary>
        /// 获取指定的学生信息
        /// </summary>
        /// <param name="stuId"></param>
        /// <returns></returns>
        public StudentInfo GetStudent(int stuId)
        {
            return studentDAL.GetStudent(stuId);
        }

        /// <summary>
        /// 添加学生
        /// </summary>
        /// <param name="stuInfo"></param>
        /// <returns></returns>
        public bool AddStudent(StudentInfo stuInfo)
        {
            return studentDAL.AddStudent(stuInfo);
        }

        public bool UpdateStudent(StudentInfo stuInfo)
        {
            return studentDAL.UpdateStudent(stuInfo);
        }

        public List<StudentInfo> GetStudentList(int classId, string keywords)
        {
            List<StudentInfo> list= studentDAL.GetStudentList(classId, keywords);
            list.ForEach(s => s.IsMale = s.Sex == "男" ? true : false);
            return list;
        }

        public bool DeleteStudent(int stuId)
        {
            return studentDAL.DeleteStudent(stuId, 0, 1);
        }
    }
}
