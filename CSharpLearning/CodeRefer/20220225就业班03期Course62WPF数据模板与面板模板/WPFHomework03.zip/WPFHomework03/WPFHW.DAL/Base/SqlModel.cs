﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Base
{
    /// <summary>
    /// 封装Insert  update语句生成的结果：sql    参数数组
    /// </summary>
     public class SqlModel
    {
        public string Sql { get; set; }
        public SqlParameter[] Paras { get; set; }
    }
}
