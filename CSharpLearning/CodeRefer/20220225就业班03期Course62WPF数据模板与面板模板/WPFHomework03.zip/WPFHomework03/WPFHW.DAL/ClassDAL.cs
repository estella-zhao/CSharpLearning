﻿using DAL.Base;
using Helper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
    public  class ClassDAL : BaseDAL<ClassInfo>
    {
        /// <summary>
        /// 获取班级列表
        /// </summary>
        /// <param name="gradeId"></param>
        /// <returns></returns>
        public List<ClassInfo> GetClassList(int gradeId)
        {
            return GetModelList($"GradeId={gradeId} and IsDeleted=0", "ClassId,ClassName", "");
        }

        public List<ClassInfo> GetClassList()
        {
            return GetModelList("", "", 0);
        }

        public List<ClassInfo> GetClassList(int gradeId,string keywords)
        {
            string strWhere = " IsDeleted=0";
            if(gradeId>0)
            {
                strWhere += $" and  GradeId={gradeId}";
            }
            if(!string.IsNullOrEmpty(keywords))
            {
                strWhere += " and ClassName like @keywords";
            }
            SqlParameter para = new SqlParameter("@keywords", $"%{keywords}%");
            return GetModelList(strWhere, "ClassId,ClassName,GradeId,Remark", "",para);
        }

        public bool DeleteClass(int classId, int delType, int isDeleted)
        {
            List<string> sqlList = new List<string>();

            string strWhere = $"ClassId={classId}";
            if (delType == 0)
            {
                string delClass = CreateSql.CreateLogicDeleteSql<ClassInfo>(strWhere, isDeleted);
                string delStudent = CreateSql.CreateLogicDeleteSql<ClassInfo>(strWhere, isDeleted);
                sqlList.Add(delClass);
                sqlList.Add(delStudent);
            }
            else if (delType == 1)
            {
                string delClass = CreateSql.CreateDeleteSql<ClassInfo>(strWhere);
                string delStudent = CreateSql.CreateDeleteSql<ClassInfo>(strWhere);
                sqlList.Add(delClass);
                sqlList.Add(delStudent);
            }
            return SqlHelper.ExecuteTrans(sqlList);
        }

        public bool AddClass(ClassInfo classInfo)
        {
            return Add(classInfo, "ClassName,GradeId,Remark", 0) > 0;
        }

        public bool UpdaeClass(ClassInfo classInfo)
        {
            return Update(classInfo, "");
        }
    }
}
