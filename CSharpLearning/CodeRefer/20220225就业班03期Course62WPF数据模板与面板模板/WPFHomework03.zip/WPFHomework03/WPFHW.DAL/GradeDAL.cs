﻿using DAL.Base;
using Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
    public class GradeDAL : BaseDAL<GradeInfo>
    {
        /// <summary>
        /// 获取年级列表
        /// </summary>
        /// <returns></returns>
        public List<GradeInfo> GetAllGrades()
        {
            return GetModelList("", "", 0);
        }

        public bool AddGrade(GradeInfo grade)
        {
            return Add(grade, "GradeName", 0) > 0;
        }

        public bool UpdaeGrade(GradeInfo grade)
        {
            return Update(grade, "");
        }

        /// <summary>
        /// 删除年级列表
        /// </summary>
        /// <param name="gradeIds"></param>
        /// <param name="delType"></param>
        /// <param name="isDeleted"></param>
        /// <returns></returns>
        public bool DeleteGradeList(List<int> gradeIds, int delType, int isDeleted)
        {
            List<string> sqlList = new List<string>();

            foreach (int id in gradeIds)
            {
                string strWhere = $"GradeId={id}";
                if (delType == 0)
                {
                    string delGrade = CreateSql.CreateLogicDeleteSql<GradeInfo>(strWhere, isDeleted);
                    string delClass = CreateSql.CreateLogicDeleteSql<ClassInfo>(strWhere, isDeleted);
                    string delStudent = CreateSql.CreateLogicDeleteSql<ClassInfo>(" ClassId in (select ClassId from ClassInfos where  " + strWhere + ")", isDeleted);
                    sqlList.Add(delGrade);
                    sqlList.Add(delClass);
                    sqlList.Add(delStudent);
                }
                else if (delType == 1)
                {
                    string delGrade = CreateSql.CreateDeleteSql<GradeInfo>(strWhere);
                    string delClass = CreateSql.CreateDeleteSql<ClassInfo>(strWhere);
                    string delStudent = CreateSql.CreateDeleteSql<ClassInfo>(" ClassId in (select ClassId from ClassInfos where  " + strWhere + ")");
                    sqlList.Add(delGrade);
                    sqlList.Add(delClass);
                    sqlList.Add(delStudent);
                }
            }
            return SqlHelper.ExecuteTrans(sqlList);
        }
    }
}
