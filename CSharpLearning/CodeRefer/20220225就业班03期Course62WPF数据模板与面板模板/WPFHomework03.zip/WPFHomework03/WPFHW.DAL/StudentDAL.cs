﻿using DAL.Base;
using Helper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFHW.Models;

namespace WPFHW.DAL
{
    public class StudentDAL : BaseDAL<StudentInfo>
    {
        public bool ExistStudent(string stuName,string phone)
        {
            string strWhere = "StuName=@stuName and Phone=@phone and IsDeleted=0";
            SqlParameter[] paras =
            {
                new SqlParameter("@stuName",stuName),
                new SqlParameter("@phone",phone)
            };
            return Exists(strWhere, paras);
        }

        public StudentInfo GetStudent(int stuId)
        {
            string cols = CreateSql.GetColNames<StudentInfo>("IsMale");
            return GetById(stuId, cols);
        }

        /// <summary>
        /// 添加学生
        /// </summary>
        /// <param name="stuInfo"></param>
        /// <returns></returns>
        public bool AddStudent(StudentInfo stuInfo)
        {
            string cols = CreateSql.GetColNames<StudentInfo>("StuId,IsMale");
            return Add(stuInfo, cols, 0) > 0;
        }

        /// <summary>
        /// 修改学生
        /// </summary>
        /// <param name="stuInfo"></param>
        /// <returns></returns>
        public bool UpdateStudent(StudentInfo stuInfo)
        {
            string cols = CreateSql.GetColNames<StudentInfo>("IsMale");
            return Update(stuInfo, cols);
        }


        public List<StudentInfo> GetStudentList(int classId, string keywords)
        {
            string cols = CreateSql.GetColNames<StudentInfo>("IsMale");
            string strWhere = " IsDeleted=0";
            if (classId > 0)
            {
                strWhere += $" and  ClassId={classId}";
            }
            if (!string.IsNullOrEmpty(keywords))
            {
                strWhere += " and (StuName like @keywords or Phone like @keywords or Interestings  like @keywords ) ";
            }
            SqlParameter para = new SqlParameter("@keywords", $"%{keywords}%");
            return GetModelList(strWhere, cols, "", para);
        }

        public bool DeleteStudent(int stuId, int delType, int isDeleted)
        {
            string delStudent = "";
            string strWhere = $"StuId={stuId}";
            if (delType == 0)
            {
                 delStudent = CreateSql.CreateLogicDeleteSql<StudentInfo>(strWhere, isDeleted);
            }
            else if (delType == 1)
            {
                delStudent = CreateSql.CreateDeleteSql<StudentInfo>(strWhere);
            }
            return SqlHelper.ExecuteNonQuery(delStudent, 1)>0;
        }
    }
}
