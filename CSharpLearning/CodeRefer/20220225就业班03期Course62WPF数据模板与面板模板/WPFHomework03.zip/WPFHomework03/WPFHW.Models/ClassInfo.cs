﻿using Common.CustAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFHW.Models
{
    [Table("ClassInfos")]
    [PrimaryKey("ClassId", autoIncrement = true)]
    public class ClassInfo
    {
        public int ClassId { get; set; }
        public string ClassName { get; set; }
        public int GradeId { get; set; }
        public string Remark { get; set; }
    }
}
