﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WPFHomework01
{
    /// <summary>
    /// ClassPage.xaml 的交互逻辑
    /// </summary>
    public partial class ClassPage : Page
    {
        GradeBLL gradeBLL = new GradeBLL();
        ClassBLL classBLL = new ClassBLL();
        public ClassPage()
        {
            InitializeComponent();
        }
        List<GradeInfo> gradeList = null;
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            gradeList = gradeBLL.GetAllGrades();
            gradeList.Insert(0, new GradeInfo() { GradeId = 0, GradeName = "请选择" });
            cboGrades.ItemsSource = gradeList;
            cboGrades.SelectedIndex = 0;
            colGrades.ItemsSource = gradeList;
            LoadList();//班级列表
        }

        private void LoadList()
        {
            string keywords = txtClassName.Text.Trim();
            int gradeId = cboGrades.SelectedValue.GetInt();
            List<ClassInfo> classList = classBLL.GetClassList(gradeId, keywords);
            dgClassList.ItemsSource = classList;
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            ClassInfoWindow classWin = new ClassInfoWindow();
            classWin.Tag = btn.Tag;
            classWin.ReloadList += LoadList;
            classWin.ShowDialog();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if(btn.Tag!=null)
            {
                int classId = btn.Tag.GetInt();
                if(MsgHelper.ShowQuestion("你确定要删除该班级吗？","班级删除")==MessageBoxResult.Yes)
                {
                    bool blDel = classBLL.DeleteClass(classId);
                    if(blDel)
                    {
                        MsgHelper.ShowMsg("班级删除成功！", "班级删除");
                        LoadList();
                    }
                    else
                    {
                        MsgHelper.ShowErrMsg("班级删除失败！", "班级删除");
                        return;
                    }
                }
              
            }
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            LoadList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassInfoWindow classWin = new ClassInfoWindow();
            classWin.ReloadList += LoadList;
            classWin.ShowDialog();
        }
    }
}
