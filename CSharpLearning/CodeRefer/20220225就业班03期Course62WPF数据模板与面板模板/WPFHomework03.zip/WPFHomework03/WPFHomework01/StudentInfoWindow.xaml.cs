﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WPFHomework01
{
    /// <summary>
    /// StudentInfoWindow.xaml 的交互逻辑
    /// </summary>
    public partial class StudentInfoWindow : Window
    {
        public StudentInfoWindow()
        {
            InitializeComponent();
        }
        GradeBLL gradeBLL = new GradeBLL();
        ClassBLL classBLL = new ClassBLL();
        StudentBLL stuBLL = new StudentBLL();

        public event Action ReloadList;
        int editStuId = 0;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.Tag != null)
            {
                editStuId = this.Tag.GetInt();
            }
            //加载年级列表
            LoadGradeList();
            if (editStuId > 0)
            {
                StudentInfo stuInfo = stuBLL.GetStudent(editStuId);
                if (stuInfo != null)
                {
                    txtName.Text = stuInfo.StuName;
                    txtPhone.Text = stuInfo.Phone;
                    int classId = stuInfo.ClassId;
                    ClassInfo classInfo = classBLL.GetClass(classId);
                    int gradeId = 0;
                    if (classInfo != null)
                        gradeId = classInfo.GradeId;
                    cboGrades.SelectedValue = gradeId;
                    cboClasses.SelectedValue = classId;
                    bool isMale= stuInfo.Sex == "男" ? true : false;
                    if (isMale)
                        rbtnMale.IsChecked = true;
                    else
                        rbtnFemale.IsChecked = true;
                    string interestings = stuInfo.Interestings;
                    if(!string.IsNullOrEmpty(interestings))
                    {
                        string[] strs = interestings.Split(',');
                        foreach (UIElement ele in spInterests.Children)
                        {
                            if (ele is CheckBox)
                            {
                                CheckBox chk = ele as CheckBox;
                                if(strs.Contains(chk.Content.ToString()))
                                {
                                    chk.IsChecked = true;
                                }
                            }
                        }
                    }
                }
                btnOK.Content = "修改";
            }
            else
            {
                cboGrades.SelectedIndex = 0;
                btnOK.Content = "新增";
            }
        }

        private void LoadGradeList()
        {
            List<GradeInfo> gradeList = gradeBLL.GetAllGrades();
            gradeList.Insert(0, new GradeInfo() { GradeId = 0, GradeName = "请选择" });
            cboGrades.ItemsSource = gradeList;
            cboGrades.DisplayMemberPath = "GradeName";
            cboGrades.SelectedValuePath = "GradeId";
            cboGrades.SelectedIndex = 0;
        }

        private void cboGrades_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int gradeId = cboGrades.SelectedValue.GetInt();
            List<ClassInfo> classList = classBLL.GetClassList(gradeId);
            classList.Insert(0, new ClassInfo() { ClassId = 0, ClassName = "请选择" });
            cboClasses.ItemsSource = classList;
            cboClasses.DisplayMemberPath = "ClassName";
            cboClasses.SelectedValuePath = "ClassId";
            cboClasses.SelectedIndex = 0;
        }

        /// <summary>
        /// 提交学生信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text.Trim();
            int classId = cboClasses.SelectedValue.GetInt();
            string sex = rbtnMale.IsChecked == true ? "男" : "女";
            string interests = "";
            foreach(UIElement ele in spInterests.Children)
            {
                if(ele is CheckBox)
                {
                    CheckBox chk = ele as CheckBox;
                    if(chk.IsChecked==true)
                    {
                        if (interests != "") interests += ",";
                        interests += chk.Content.ToString();
                    }
                }
            }
            string phone = txtPhone.Text.Trim();

            if(string.IsNullOrEmpty(name))
            {
                MsgHelper.ShowErrMsg("请输入学生姓名！","新增学生");
                return;
            }
            if(classId==0)
            {
                MsgHelper.ShowErrMsg("请选择所属班级！", "新增学生");
                return;
            }
            if (string.IsNullOrEmpty(phone))
            {
                MsgHelper.ShowErrMsg("请输入手机号码！", "新增学生");
                return;
            }
            if(editStuId==0)
            {
                bool blExist = stuBLL.ExistStudent(name, phone);
                if (blExist)
                {
                    MsgHelper.ShowErrMsg("该学生信息已存在！", "新增学生");
                    return;
                }
            }
            else
            {
                StudentInfo stuInfo = new StudentInfo()
                {
                    StuId=editStuId,
                    StuName = name,
                    Sex = sex,
                    ClassId = classId,
                    Interestings = interests,
                    Phone = phone
                };
                bool blAdd = false;
                if (editStuId == 0)
                    blAdd = stuBLL.AddStudent(stuInfo);
                else
                    blAdd = stuBLL.UpdateStudent(stuInfo);
                if (blAdd)
                {
                    MsgHelper.ShowMsg("学生提交成功！", "学生信息");
                    ReloadList?.Invoke();
                    this.Close();
                }
                else
                {
                    MsgHelper.ShowErrMsg("学生提交失败！", "学生信息");
                    return;
                }
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
