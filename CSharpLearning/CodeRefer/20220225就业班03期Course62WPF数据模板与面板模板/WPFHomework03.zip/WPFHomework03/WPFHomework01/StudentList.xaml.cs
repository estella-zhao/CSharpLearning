﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPFHW.BLL;
using WPFHW.Models;

namespace WPFHomework01
{
    /// <summary>
    /// StudentList.xaml 的交互逻辑
    /// </summary>
    public partial class StudentList : UserControl
    {
        ClassBLL classBLL = new ClassBLL();
        StudentBLL stuBLL = new StudentBLL();
        public StudentList()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            List<ClassInfo> classList = classBLL.GetClassList();
            classList.Insert(0, new ClassInfo() { ClassId = 0, ClassName = "请选择" });
            cboClasses.ItemsSource = classList;
            cboClasses.SelectedIndex = 0;
            colClasses.ItemsSource = classList;
            LoadList();//学生列表
        }

        private void LoadList()
        {
            string keywords = txtKeyWords.Text.Trim();
            int classId = cboClasses.SelectedValue.GetInt();
            List<StudentInfo> stuList = stuBLL.GetStudentList(classId, keywords);
            dgStudentList.ItemsSource = stuList;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            StudentInfoWindow stuWin = new StudentInfoWindow();
            stuWin.ReloadList += LoadList;
            stuWin.ShowDialog();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            LoadList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            StudentInfoWindow stuWin = new StudentInfoWindow();
            stuWin.ReloadList += LoadList;
            stuWin.Tag = btn.Tag;
            stuWin.ShowDialog();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn.Tag != null)
            {
                int stuId = btn.Tag.GetInt();
                if (MsgHelper.ShowQuestion("你确定要删除该学生吗？", "学生删除") == MessageBoxResult.Yes)
                {
                    bool blDel = stuBLL.DeleteStudent(stuId);
                    if (blDel)
                    {
                        MsgHelper.ShowMsg("学生删除成功！", "学生删除");
                        LoadList();
                    }
                    else
                    {
                        MsgHelper.ShowErrMsg("学生删除失败！", "学生删除");
                        return;
                    }
                }

            }
        }

       
    }
}
