﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WPFHomework01
{
    /// <summary>
    /// StudentMainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class StudentMainWindow : Window
    {
        public StudentMainWindow()
        {
            InitializeComponent();
        }

        private void btnAddStudent_Click(object sender, RoutedEventArgs e)
        {
            StudentInfoWindow stuInfoWin = new StudentInfoWindow();
            stuInfoWin.ShowDialog();
        }
        DispatcherTimer timer = null;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if(this.Tag!=null)
            {
                string loginName = this.Tag.ToString();
                lblLoginName.Content = loginName;
                lblSLoginName.Content = loginName;
                lblRights.Content = "朝夕教育所有";
                timer = new DispatcherTimer();
                timer.Interval = new TimeSpan(1000);
                timer.Tick += Timer_Tick;
                timer.Start();
                //动态时间条
                //Task.Run(() =>
                //{
                //    while(true)
                //    {
                //        this.Dispatcher.BeginInvoke(new Action(() =>
                //        {
                //            lblCurrentTime.Content = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                //        }));
                //        Thread.Sleep(1000);
                //    }
                    
                //});
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Dispatcher.Invoke(() =>
            {
                lblCurrentTime.Content = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            });
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
